import React from "react";
import  "react-dom";
import "../assest/header.css"; 
import "../assest/sections.css"
import "../assest/bootstrap.min.css"; 
//  import App from "./App"; const rootElement = document.
import "react-bootstrap"
// import "bootstrap/dist/css"
import "bootstrap"
import img from '../images/bg-home.jpg'
// import pbb from '../images/bg-pattern.png'


function Home(){
    return(
      <div>
     
       {/* <nav className="navbar">
        <div className="navbar-container container">
         <div className="_drsn"><h1 className="logo">DORSIN</h1></div>   
        <input type="checkbox" name="" id="" />
        <div className="hamburger-lines">
          <span className="line line1"></span>
          <span className="line line2"></span>
          <span className="line line3"></span>
        </div>
        
        <ul className="menu-items">
            <li className="._dsn">  <h1>DORSIN</h1>
             </li>
             <li></li>
          <li><a href="#">Home</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Features</a></li>
          <li><a href="#">Pricing</a></li>
          <li><a href="#">Team</a></li>
          <li><a href="#">Blog</a></li> 
          <li><a href="#">Contact</a></li>
          <button><a href="#">Contact</a></button> 
          </ul>
        <ul className="menu-items">
            <button><a href="#">Try it Free</a></button>
            </ul>
     
      </div>
    </nav>   */}
    
            
          <section className=" section  bg-home  " >
            
                <h1 class="home-title">We help startups launch their <br/> products</h1>
                <p class="pt-3 home-desc">Etiam sed.Interdum consequat proin vestibulum class at.</p>
                <p class="play-shadow mt-4"><a class="play-btn video-play-icon" href="/">
                  <i class="mdi mdi-play text-center"></i></a></p>
          </section>
          <section>
        <h1 class="text-center">Our Services</h1>
        <p class=" text-center ">We craft digital, graphic and dimensional thinking, to create category leading brand experiences that have meaning and add a value for our clients.</p>
          </section>
    </div>
    )
  
    
   
    
    
}

export default Home;